var toolbar_loaded = false;

//if button is clicked to show toolbar
chrome.extension.onMessage.addListener(function(msg, sender, sendResponse) {
	if(toolbar_loaded==false){
		if (msg.action == 'start') {
			toolbar_loaded = true;
		    start();
		  }		
	}else{
		$(document).find('#MyNisomaExtensionForSerpResults').remove();
		toolbar_loaded = false;
		$('body').css({
			'-webkit-transform':'translateY(0)'
		});
	}
	  
});

function start(){
	//console.log('NISOMA SERP EXTENSION');
	
	chrome.runtime.sendMessage({method: "set", key: "domain", value: window.location.origin}, function(response) {
		// console.log(response);
	});

	var url = chrome.extension.getURL("toolbar.html");
	var height = "200px";
	var iframe = '<iframe src="' + url + '" id="MyNisomaExtensionForSerpResults" style="height:'+height+';"></iframe>';

	$(iframe).insertAfter('body');
	$('body').css({
		'-webkit-transform':'translateY('+height+')'
	});
}


/*  last commented
var keywords = $('meta[name=keywords]').attr("content");
if(typeof keywords === 'undefined'){
	keywords = $('meta[name=Keywords]').attr("content");
}
var url = window.location.href;
var domain = window.location.origin;


chrome.runtime.sendMessage({method: "setBGLocalStorageByKey", key: "keywords", value: keywords}, function(response) {
  console.log(response.data);
});
chrome.runtime.sendMessage({method: "setBGLocalStorageByKey", key: "domain", value: domain}, function(response) {
  console.log(response.data);
});
chrome.runtime.sendMessage({method: "setBGLocalStorageByKey", key: "url", value: url}, function(response) {
  console.log(response.data);
});


*/



// send to background.js 
/*var someVar = "hey hey!";

chrome.extension.sendRequest({method: "myScript",greeting: someVar}, function(response) {

    console.log(response.data); // response back from BG

    if(response.who == 'bg'){ // checks if the response is from BG
            //Something happened ...
    }

    var responseFromBg = response.data; // the response incase we need to use the message sent back... in this case should be 'hey yourself'

	
}); */

/*
if (!localStorage.pageLoadCount)
    localStorage.pageLoadCount = 0;
  localStorage.pageLoadCount = parseInt(localStorage.pageLoadCount) + 1;
  console.log( localStorage.pageLoadCount);
  
  localStorage.title = document.title; 
  */
  
