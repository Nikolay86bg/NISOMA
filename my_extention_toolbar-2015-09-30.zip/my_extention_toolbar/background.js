chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {	
    if(request.method == "set"){
    	localStorage.setItem(request.key,request.value);    
    	sendResponse({data: request.key+" is saved!"});
    }else if(request.method == "get"){
    	sendResponse({data: localStorage.request.key});
    }else{
    	sendResponse({data: "Unknown method send to background.js"});
    }
});



// chrome.runtime.onMessage.addListener(function(response,sender,sendResponse){
	// alert(response);
	// return 'return value';
// });
/*
chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
  // From content script.
  if (sender.tab) {

    if (request.method == "myScript"){
			
        localStorage.setItem("welcome-message",request.greeting); // in this case there will now be a localStorage variable called 'welcome-message' set with the value of 'hey hey!'. This will be viewable in the chrome:extensions page, click on the 'background.html / generated background.html' then view the 'Development Tools' or in Windows hit 'CTRL + SHIFT + I' and look at the 'LocalStorage' tab...

      sendResponse({who: "bg",data: "hey yourself"}); // this is the response sent back, 'who' tells the content page where is responding, so it can do something with the response if needed.

    }else{
      sendResponse({}); // snub them.
    }
  }
});*/




