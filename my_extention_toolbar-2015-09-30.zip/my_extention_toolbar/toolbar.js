$( document ).ready(function() {
  console.log('started');
  
  //check if keywords Storage exists and create it
  // console.log(typeof (localStorage.keywords));
  if(typeof (localStorage.keywords) == "undefined"){
	  console.log("setting new keyword storage");
	  localStorage.setItem("keywords",JSON.stringify({"domains":{}}));
  }
  	
	show_all_keywords_for_current_domain();
});

function show_all_keywords_for_current_domain(){
	saved_keywords = JSON.parse(localStorage.keywords)['domains'][localStorage.domain];
	// console.log(saved_keywords);
	var keywords = saved_keywords.split(", ");
	var list = "";
	for (i = 0; i < keywords.length; i++) { 
		list = list + '<li>'+keywords[i]+' <span class="red remove_keyword" alt="' + keywords[i] + '">x</span> '+'</li>'; 
	}
	$(".k-list").html(list);
}

function remove_keyword(del_keyword){ 
	
	saved_keywords = JSON.parse(localStorage.keywords);
	   $.each( saved_keywords.domains, function( storage_domain, storage_keywords ) {
			if(localStorage.domain == storage_domain){
				var keywords = storage_keywords.split(", ");
				
				var index = keywords.indexOf(del_keyword);
				keywords.splice( index, 1 );
				new_keywords = keywords.toString()
				saved_keywords['domains'][storage_domain] = new_keywords.replace(/,/gi, ", ");;				
				localStorage.setItem("keywords",JSON.stringify(saved_keywords));
				// alert('Keyword is deleted!');
				}
			
	   });
}

function save_data_from_uploaded_file(data){

	var uploaded_keywords = '';
	var i = 0;
	$.each(data, function( key, value ){
		if(i!=0){
			uploaded_keywords = uploaded_keywords + ', ' + value[0];
		}else{
			uploaded_keywords = value[0]; i++;			
		}
		// $('.k-list').append('<li>'+value[0]+' <span class="red remove_keyword" alt="' + value[0] + '">x</span> '+'</li>');
	});
	
	var is_new_domain = true; // IS it a new domain		 
	saved_keywords = JSON.parse(localStorage.keywords);
	
	$.each( saved_keywords.domains, function( storage_domain, storage_keywords ) {
		if(localStorage.domain == storage_domain){			
			new_keywords = storage_keywords + ', ' + uploaded_keywords;
			saved_keywords['domains'][storage_domain] = new_keywords;
			localStorage.setItem("keywords",JSON.stringify(saved_keywords));
			is_new_domain = false;				
		}
	});

	if(is_new_domain == true){
	 saved_keywords['domains'][localStorage.domain] = uploaded_keywords;
	 localStorage.setItem("keywords",JSON.stringify(saved_keywords));
	}
	alert('New keywords are uploaded from file!');	
	location.reload();	
}

// Method that checks that the browser supports the HTML5 File API (for CSV UPLOAD)
function browserSupportFileUpload() {
	var isCompatible = false;
	if (window.File && window.FileReader && window.FileList && window.Blob) {
	isCompatible = true;
	}
	return isCompatible;
}
	
// Method that reads and processes the selected file (for CSV UPLOAD)
function upload(evt) {
    if (!browserSupportFileUpload()) {
        alert('The File APIs are not fully supported in this browser!');
        } else {
            var data = null;
            var file = evt.target.files[0];
            var reader = new FileReader();
            reader.readAsText(file);
            reader.onload = function(event) {
                var csvData = event.target.result;
                data = $.csv.toArrays(csvData);
                if (data && data.length > 0) {
                  // alert('Imported -' + data.length + '- rows successfully!');
				  save_data_from_uploaded_file(data); 
                } else {
                    alert('No data to import!');
                }
            };
            reader.onerror = function() {
                alert('Unable to read ' + file.fileName);
            };
        }
}

document.addEventListener('DOMContentLoaded', function() {
	 // The event listener for the file upload
    document.getElementById('txtFileUpload').addEventListener('change', upload, false);
	
	$('.remove_keyword').on("click", function(){
		remove_keyword($(this).attr('alt'));
		$(this).parent().remove();		
	});
		
	//Get SERP Results
    $('.buttonx').on("click", function(){	
		 console.log(localStorage.keywords);
		 console.log(localStorage.domain);
		if(localStorage.keywords == "undefined"){ alert("No keywords meta tag!"); return;}
		
		saved_keywords = JSON.parse(localStorage.keywords)['domains'][localStorage.domain];
		
		var keywords = saved_keywords.split(", ");
		var results = "";		
		var results_for_csv = "Keywords; Position, \r\n ";
		
		for (i = 0; i < keywords.length; i++) { 
			search_query = keywords[i].trim().replace(/ /g, "+").toString();
			// console.log("https://www.google.co.uk/search?num=100&q="+search_query);
			
			 $.ajax({
				type: "GET",
				url: "https://www.google.co.uk/search?num=50&q="+search_query,
				async: false,
				success : function(response) {
					var search_results =  $(response).find(".r a").toArray();		
					for (x = 0; x < search_results.length; x++) { 
						value = search_results[x].toString();
						if(value.indexOf(localStorage.domain) == 0){
							// console.log("For "+search_query+" position is: "+ (x+1));
							// $('.results').append("<br/>For "+search_query+" position is: <span class=\"red\">"+ (x+1) + "</span>");	
							
							results = results + "<li>"+search_query+" <span class=\"red\">"+ (x+1) + "</span></li>"		
							results_for_csv = results_for_csv + search_query.replace(/\+/g, " ") + ";" + (x+1) + "\r\n";
							break;
						} 
					}
				}
			});			
		}
		
		//Date
		var today = new Date();
		var short_domain = localStorage.domain.split(".");
		var filename = (today.getFullYear()).toString()  + ("0"+(+today.getMonth()+1).toString()).slice(-2) + (today.getDate()).toString() + "___" + short_domain[1] + ".csv";
		
		// console.log(filename);
		// console.log(results_for_csv);
		
		//Download as CSV link
		var link = document.createElement("a");
		link.textContent = "Save result as CSV";
		link.download = filename;
		link.href = 		'data:text/csv;charset=utf-8,'  + escape(results_for_csv);
		
		$('.results').html(results);	
		$('.results').append(link);				
	});
	
	$('.add_keyword_button').on("click", function(){
		 if(typeof $('.keyword').val() != "undefined"){ var keyword = $('.keyword').val(); }		 
		 
			var is_new_domain = true; // IS it a new domain		 
			if(keyword){
			  saved_keywords = JSON.parse(localStorage.keywords);
			   $.each( saved_keywords.domains, function( storage_domain, storage_keywords ) {
				// console.log('domain -> '+storage_domain+' keywords -> '+storage_keywords);
					if(localStorage.domain == storage_domain){
						new_keywords = storage_keywords + ', ' + keyword;
						saved_keywords['domains'][storage_domain] = new_keywords;
						localStorage.setItem("keywords",JSON.stringify(saved_keywords));
						is_new_domain = false;
						// alert('New keyword is added!');
						$('.keyword').val("");
						// show_all_keywords_for_current_domain();
					    
						// $('.k-list').append('<li>'+keyword+' <span class="red remove_keyword" alt="' + keyword + '">x</span> '+'</li>');
					}
					
			   });
			   
			   if(is_new_domain == true){
					 saved_keywords['domains'][localStorage.domain] = keyword;
					 localStorage.setItem("keywords",JSON.stringify(saved_keywords));
					 // alert('New keyword is added!');
					 $('.keyword').val("");
					 // $('.k-list').append('<li>'+keyword+' <span class="red remove_keyword" alt="' + keyword + '">x</span> '+'</li>');
				 }
			 }else{ alert('Empty keyword field!');}			
			
			location.reload();			 
	 });
});


/*chrome.runtime.sendMessage({method: "setBGLocalStorageByKey", key: "keywords", value: localStorage.keywords + ', ' +keyword}, function(response) {
		  console.log(response.data);
		 });*/
		 
		 
/*
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
     activeTab = tabs[0];
     ID = tabs[0].id; // or do whatever you need	 
	 URL = tabs[0].url; //URL
	 TITLE = tabs[0].title; //URL
	 $('.show').html('Domain is: '+URL);
	 $('.show').append('<br>Title is: '+TITLE);
	 
	 $('.show').append('<br>New key is: '+localStorage.new_key);
	 // localStorage.setItem("id",ID);
	 // localStorage.setItem("url",URL);
	 // localStorage.setItem("title",TITLE);
	 
	// localStorage.setItem("title","hello in extension page2"); //this is how we save it in locastorage of extention page
});
*/

